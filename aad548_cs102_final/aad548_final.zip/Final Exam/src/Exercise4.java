

public class Exercise4 {
    // See word document.
 }
 
 